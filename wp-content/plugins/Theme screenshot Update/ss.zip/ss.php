<?php

/**
 * Form Plugin
 *
 * Plugin Name: Auto Add Theme Screen Short
 * Version:     1.0.0
 * Text Domain: add ss
 * Domain Path: /languages
 */
/**
 * 
 */
echo $my_themeName = wp_get_theme();
// cass and js enqueue
function enqueue_scripts()
{
  wp_enqueue_style('docs', plugin_dir_url(__FILE__) . '/css/docs.css');
  wp_enqueue_style('bootstrap.min', plugin_dir_url(__FILE__) . '/css/bootstrap.min.css');
  
}
add_action('admin_enqueue_scripts', 'enqueue_scripts');

// Add Option On Setting
add_action('init', 'add_auto_theme_ss');
add_action('admin_menu', 'add_theme_ss');
function add_theme_ss()
{
    add_options_page(
        'ScreenShort', // page <title>Title</title>
        'Add ScreenShort', // menu link text
        'manage_options', // capability to access the page
        'add-screenshort', // page URL slug
        'auto_add_screenshort', // callback function with content
        2 // priority
    );
}

function replace_alt_title_flush_rewrites()
{
    replace_alt_title_myplugin();
    flush_rewrite_rules();
}

// click button call this function
function auto_add_screenshort()
{ ?>
    <div>
        <h2>Auto Add ScreenShort To Activty Theme</h2>
        <h3>Click The Button And See The Magic !</h3>
        <button type="button" data-action="find" onClick="" class="btn btn-success find">Add Screen Short</button>
    </div>
<?php
// get theme name
echo $my_themeName = wp_get_theme();
// get theme url
$theme_url= get_template_directory_uri();
}
?>